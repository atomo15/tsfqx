import Car

if __name__ == "__main__":
    mustang = Car.Car()
    mustang.setName("mustang")
    print(mustang.get_name())
    print(mustang.get_num_wheels())


class Vehicle():

    def setName(self,name):
        self.name = name

    def get_name(self):
        return self.name
